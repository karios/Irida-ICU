﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;

namespace ICU.Net
{
    public class UdpState
    {

        public IPEndPoint e;
        public UdpClient u;

    }
}
